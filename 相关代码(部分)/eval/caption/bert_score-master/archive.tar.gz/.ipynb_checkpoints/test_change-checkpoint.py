import logging
import transformers
transformers.tokenization_utils.logger.setLevel(logging.ERROR)
transformers.configuration_utils.logger.setLevel(logging.ERROR)
transformers.modeling_utils.logger.setLevel(logging.ERROR)

from bert_score import score

# 读取参考文本和模型预测文本
with open("referrence.txt") as f:
    cands = [line.strip() for line in f]

with open("model_predict.txt") as f:
    refs = [line.strip() for line in f]


# 打印第一行的参考文本
print(cands[0])

# 逐行计算 F1 分数并输出
for i, (cand, ref) in enumerate(zip(cands, refs)):
    P, R, F1 = score([cand], [ref], lang='en', verbose=True)
    print(f"Line {i+1} - F1 score with original reference: {F1.mean():.3f}")